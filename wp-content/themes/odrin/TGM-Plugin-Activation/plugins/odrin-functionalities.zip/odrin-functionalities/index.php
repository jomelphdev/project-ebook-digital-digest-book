<?php
/**
 * Plugin Name: Odrin Functionalities
 * Plugin URI: http://www.subsolardesigns.com
 * Description: Adds the functionalities of the Odrin theme
 * Version: 1.0.4
 * Author: Subsolar Designs
 * Author URI: http://www.subsolardesigns.com
 * Text Domain: odrin
 * Domain Path: language
*/	


/**
 * Includes
 */
require_once( plugin_dir_path( __FILE__ ) . 'inc/subsolar-widget-fields/subsolar-widget-fields.php');
require_once( plugin_dir_path( __FILE__ ) . 'inc/hooks.php' );